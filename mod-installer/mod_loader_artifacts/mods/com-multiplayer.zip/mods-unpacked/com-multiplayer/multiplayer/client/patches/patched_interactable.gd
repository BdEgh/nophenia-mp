extends interactable
class_name patched_interactable

func interact() -> bool:
    var nia := get_tree().get_first_node_in_group("player")
    if !is_trigger:
        if game.active_stage.anomaly_occurring or uninteractable:
            nia.no()
            return false
        else:
            game.rumble(0, 0.2, 0.22, 0.06)
            match _id:
                1:
                    create_tween().tween_property(get_tree().get_first_node_in_group("player").chara, "global_rotation_degrees:y", _offset_rot, 0.2)
                    create_tween().tween_property(get_tree().get_first_node_in_group("player"), "global_position", self.global_position + _offset, 0.2)
                    await nia.sit(true)
                    return false
                2:
                    audio.play_snd(_interact_sfx, -1.0, 0.2)
                    game.to_entrance = _to_entrance
                    if config.last_visited and config.last_visited != "stage_bedroom" and config.last_visited != "stage_fog":
                        change_stage(config.last_visited)
                    else:
                        change_stage(_to_stage)
                _:
                    if "toggle_umbrella" in nia:
                        nia.toggle_umbrella(false)
                    audio.play_snd(_interact_sfx, -1.0, 0.2)
                    game.to_entrance = _to_entrance
                    change_stage(_to_stage)
    return true

func change_stage(_stage: String = ""):
    if !_stage:
        change_stage_rand()
        return
    var rl = get_tree().get_first_node_in_group("mp").remote_loader
    _stage = await rl.fetch_stage(_stage)
    game.change_stage(_stage)

func change_stage_rand():
    var mp = get_tree().get_first_node_in_group("mp")
    var rng_seed = mp.mp_cfg.rng_seed
    seed(rng_seed)
    var pool = game._traverse_random.duplicate()
    if mp.mp_cfg.remote_stage_usage == 1:
        pool += mp.remote_stages_list
    if mp.mp_cfg.remote_stage_usage == 2:
        pool = mp.remote_stages_list
    pool.shuffle()
    game.to_entrance = 0
    for _n: String in pool:
        var _dream: String
        if FileAccess.file_exists(_n):
            _dream = ResourceUID.get_id_path(ResourceUID.text_to_id(_n)).get_file().get_basename()
        else:
            _dream = _n
        if _dream not in config.visited:
            change_stage(_dream)
            return
    
    config.visited.clear()
    config.last_visited = "stage_end"
    game._dream_attempt = 0
    mp.mp_cfg.rng_seed = randi()
    
    change_stage("stage_title")
    get_window().request_attention()
