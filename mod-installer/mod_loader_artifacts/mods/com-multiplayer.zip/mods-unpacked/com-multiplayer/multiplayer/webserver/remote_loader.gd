#class_name StageLoader
extends Node

@export var addr := "http://127.0.0.1:8080"
@export var remote_stages_physical := "user://remote_stages"
@export var stages_mounted := "res://stages-unpacked"

signal download_progress(value: float)

var http: HTTPRequest
var p_timer: Timer

func _ready() -> void:
    http = HTTPRequest.new()
    http.download_chunk_size = 128 * 1024
    http.use_threads = true
    add_child(http)
    
    p_timer = Timer.new()
    p_timer.wait_time = 0.1
    p_timer.autostart = false
    p_timer.timeout.connect(
        func():
            var body_size = http.get_body_size()
            var downloaded_bytes = http.get_downloaded_bytes()
            var value = downloaded_bytes / float(body_size)
            download_progress.emit(value)
    )
    add_child(p_timer)

func load_all_from_disk() -> void:
    for file in DirAccess.get_files_at(remote_stages_physical):
        var path = remote_stages_physical.path_join(file)
        load_from_disk(path)

func load_from_disk(path: String):
    if path.get_extension() != "zip" or not FileAccess.file_exists(path):
        print("unable to load: " + path)
        return
    
    var is_loaded := ProjectSettings.load_resource_pack(path, false)
    if is_loaded:
        print("loaded level: " + path)

func download_and_load(_stage: String, force: bool = false):
    if not DirAccess.dir_exists_absolute(remote_stages_physical):
        DirAccess.make_dir_absolute(remote_stages_physical)
    var physical_path = remote_stages_physical.path_join("%s.zip" % _stage)
    if not force and FileAccess.file_exists(physical_path):
        load_from_disk(physical_path)
        return
    
    http.cancel_request()
    
    p_timer.start()
    http.download_file = remote_stages_physical.path_join("%s.zip" % _stage)
    var url := addr.path_join("/load_stage?stage=%s.zip" % _stage)
    var err := http.request(url)
    if err != OK:
        printerr("%s request failed" % [_stage])
        return
    var response = await http.request_completed
    p_timer.stop()

    var res = response[0]
    var code = response[1]
    if res == HTTPRequest.RESULT_SUCCESS and code == 200:
        print("%s downloaded" % _stage)
        load_from_disk(physical_path)
    else:
        printerr("%s download failed. Code %d" % [_stage, code])

func fetch_mounted_stage(_stage: String):
    var mounted_stage = stages_mounted.path_join("%s/%s.tscn" % [_stage, _stage])
    if FileAccess.file_exists(mounted_stage):
        return mounted_stage
    return null

func download_update(_stage: String):
    await download_and_load(_stage, true)
    return fetch_mounted_stage(_stage)

func fetch_stage(_stage: String):
    if FileAccess.file_exists(_stage):
        return _stage
    var original_stage = "res://stage/%s.tscn" % _stage
    if FileAccess.file_exists(original_stage):
        return original_stage
    var mounted_stage = fetch_mounted_stage(_stage)
    if not mounted_stage:
        await download_and_load(_stage)
        mounted_stage = fetch_mounted_stage(_stage)
    return mounted_stage

func change_stage(_stage, instant = false, update = false):
    if game.transing:
        return
    if update: _stage = await download_update(_stage)
    else: _stage = await fetch_stage(_stage)
    if not _stage:
        return
    
    if not instant:
        game.trans_id = randi_range(0, 7)
        await game.trans(true)
    await RenderingServer.frame_post_draw
    get_tree().unload_current_scene()
    var _error = get_tree().change_scene_to_file(_stage)
    if _error: change_stage("stage_title")
    await get_tree().tree_changed
    await get_tree().process_frame
    # project patcher hack
    var pp = get_tree().get_first_node_in_group("proj_patcher")
    if not pp:
        var mp = get_tree().get_first_node_in_group("mp")
        mp.patch_properties(mp.d_to_a(mp.default_overrides))
    # end
    if not instant:
        game.trans(false)
    game.show_location()
    if is_instance_valid(game.active_stage):
        if !game.active_stage.is_static:
            audio.play_snd(preload("res://audio/sfx/door_shut.ogg"), -1.0, 0.2)
