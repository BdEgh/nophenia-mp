extends Node

var chat_ui_layer_res := load(get_script().resource_path.get_base_dir() + "/client/chat_ui_layer.tscn")
var client_res := load(get_script().resource_path.get_base_dir() + "/client/client.tscn")
var network_server_res := load(get_script().resource_path.get_base_dir() + "/server/server.tscn")
var network_client_res := load(get_script().resource_path.get_base_dir() + "/client/client_api.gd")
var mp_version_res := load(get_script().resource_path.get_base_dir() + "/client/mp_version.tscn")
var remote_loader_res := load(get_script().resource_path.get_base_dir() + "/webserver/remote_loader.gd")

signal client_loaded

var chat: CanvasLayer
var client: Node
var network_server: Node
var network_client: Node
var remote_loader: Node
var webserver_http: HTTPRequest

var mp_cfg_res := load(get_script().resource_path.get_base_dir() + "/mp_cfg.gd")
var mp_cfg = mp_cfg_res.new()
var default_name: String = [
    "cheese", "milk", "tea",
    "coffee", "fish", "pumpkin",
    "melon", "apple", "banana",
    "berry", "honey", "sugar",
    "kiwi", "mango", "orange"
].pick_random()

var steam: Object
var self_steam_id: int
var latest_version: String
var mod_version: String

const _SETTINGS_PATH := "user://mp.cfg"

func _ready() -> void:
    _load_config()
    if mp_cfg.init_stage != "":
        var _stage = mp_cfg.init_stage
        mp_cfg.init_stage = ""
        save_config()
        update_http_client(mp_cfg.address)
        remote_loader.change_stage(_stage, true)
    if "--server" in OS.get_cmdline_args():
        var port_override := -1
        for arg in OS.get_cmdline_args():
            if arg.begins_with("--port="):
                port_override = arg.trim_prefix("--port=").to_int()
        set_network_server(port_override, false)
    
    add_to_group("mp")
    get_tree().node_added.connect(_on_node_added)
    
    steam = Engine.get_singleton("Steam")
    if game.is_steam() and steam.steamInit():
        default_name = steam.getPersonaName()
        self_steam_id = steam.getSteamID()
    
    chat = chat_ui_layer_res.instantiate()
    add_child(chat)
    
    mod_version = _get_mod_version()
    if mod_version.ends_with(".0"):
        mod_version = mod_version.left(-2)
    print("Multiplayer v%s is ready" % mod_version)
    var existing_stage_title := get_tree().get_root().find_child("stage_title", true, false)
    if existing_stage_title:
        call_deferred("_on_stage_title", existing_stage_title)

func _get_mod_version() -> String:
    var manifest_path: String = get_script().resource_path.get_base_dir().path_join("../manifest.json").simplify_path()
    var version := "0.0.0"
    if FileAccess.file_exists(manifest_path):
        var data = FileAccess.get_file_as_string(manifest_path)
        var json = JSON.parse_string(data)
        return json["version_number"]
    return version

func _notification(event: int) -> void:
    if event == NOTIFICATION_WM_CLOSE_REQUEST:
        if is_instance_valid(game.active_stage): if game.active_stage.anomaly_occurring: return
        if game.is_steam():
            steam.steamShutdown()

func _load_config() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(_SETTINGS_PATH) != OK:
        return
    for _prop in mp_cfg.get_script().get_script_property_list():
        if cfg.has_section_key("setting", _prop.name):
            mp_cfg.set(_prop.name, cfg.get_value("setting", _prop.name))
    print("Loaded server URL from config: %s" % [mp_cfg.address])

func save_config() -> void:
    var cfg := ConfigFile.new()
    for _prop in mp_cfg.get_script().get_script_property_list():
        cfg.set_value("setting", _prop.name, mp_cfg.get(_prop.name))
    cfg.save(_SETTINGS_PATH)

func _on_node_added(node: Node) -> void:
    if node.is_in_group("player"):
        call_deferred("_attach_client")
    if node.name == "stage_title":
        call_deferred("_on_stage_title", node)

func _on_nia_exited() -> void:
    if client:
        client.queue_free()
        client = null

#region Client/Server
func _attach_client() -> void:
    var nia = get_tree().get_first_node_in_group("player")
    
    if nia:
        if not nia.tree_exited.is_connected(_on_nia_exited):
            nia.tree_exited.connect(_on_nia_exited, CONNECT_ONE_SHOT)
        if client == null:
            var map = game.active_stage
            if map.anomaly_occurring:
                return
                
            set_network_client()
            client = client_res.instantiate()
            client.get_node("PlayerSync").nia = nia
            _update_network_client()
            add_child(client)
            client_loaded.emit()
            if network_client:
                network_client.request_sync()
        apply_player_collision()

func apply_player_collision() -> void:
    var nia = get_tree().get_first_node_in_group("player")
    if not nia:
        return
    nia.set_collision_mask_value(10, mp_cfg.collision)

# todo: get rid of this
func _update_network_client() -> void:
    if not client:
        return
    client.get_node("PatchPhone").client = network_client
    client.get_node("PuppetManager").client = network_client
    client.get_node("PlayerSync").client = network_client
    chat.get_node("ChatUI").client = network_client

func ws_to_http(ws_addr: String):
    var regex = RegEx.new()
    regex.compile("^(wss?)(://[^:/]+):(\\d+)$")
    var result = regex.search(ws_addr)
    if result:
        var scheme = "https" if result.get_string(1) == "wss" else "http"
        var host = result.get_string(2)
        var port = str(result.get_string(3).to_int() + 1)
        return scheme + host + ":" + port
    return null

func update_http_client(ws_addr: String):
    if not remote_loader:
        remote_loader = remote_loader_res.new()
        remote_loader.addr = ws_to_http(ws_addr)
        add_child(remote_loader)
        webserver_http = HTTPRequest.new()
        add_child(webserver_http)
        update_remote_stage_usage()
        var remote_autoupdate = Timer.new()
        remote_autoupdate.autostart = true
        remote_autoupdate.wait_time = 60
        remote_autoupdate.timeout.connect(func():
            update_remote_stage_usage()
        )
        add_child(remote_autoupdate)
    else:
        remote_loader.addr = ws_to_http(ws_addr)
        update_remote_stage_usage()

func set_network_client() -> void:
    if network_client:
        return
    if not mp_cfg.auto_connect and not network_server:
        return
    network_client = network_client_res.new()
    network_client.name = "NetworkClient"
    if network_server:
        network_client.url = "ws://127.0.0.1:%d" % mp_cfg.server_port
    else:
        network_client.url = mp_cfg.address
    update_http_client(network_client.url)
    add_child(network_client)
    _update_network_client()
    network_client.request_sync()

func drop_network_client() -> void:
    if not network_client:
        return
    network_client.queue_free()
    network_client = null
    _update_network_client()

func set_network_server(port: int = -1, run_client: bool = true) -> void:
    if network_server:
        return
    network_server = network_server_res.instantiate()
    network_server.name = "NetworkServer"
    network_server.port = port
    if port == -1:
        network_server.port = mp_cfg.server_port
    add_child(network_server)
    if run_client:
        drop_network_client()
        set_network_client()

func drop_network_server() -> void:
    if not network_server:
        return
    network_server.queue_free()
    network_server = null
    drop_network_client()
    if mp_cfg.auto_connect:
        set_network_client()
#endregion

#region ModUpdater
var menu_http: HTTPRequest

func _on_stage_title(stage_title: Node3D) -> void:
    var canvas = stage_title.get_node("canvas_layer")
    var mp_control: Control = mp_version_res.instantiate()
    var mp_ver: RichTextLabel = mp_control.get_node("mp_version")
    mp_ver.text = "mp v%s" % [mod_version]
    var mp_upd: RichTextLabel = mp_control.get_node("update_info")
    mp_upd.visible = false
    var button: Button = mp_control.get_node("button")
    button.visible = false
    canvas.add_child(mp_control)
    canvas.move_child(mp_control, stage_title.get_node("canvas_layer/info_version").get_index() + 1)
    
    if not menu_http:
        menu_http = HTTPRequest.new()
        add_child(menu_http)
    var git_version = await _fetch_latest_version()
    if git_version != mod_version:
        mp_upd.text = "(update to v%s available)" % [git_version]
        mp_upd.visible = true
        button.visible = true
        button.pressed.connect(_on_update_pressed.bind(mp_upd))
    else:
        mp_ver.text += " (latest)"

func _fetch_latest_version() -> String:
    menu_http.request("https://api.github.com/repos/bdegh/nophenia-mp/tags")
    var result = await menu_http.request_completed
    var res = result[0]
    var code = result[1]
    var body = result[3]
    if res == OK and code == 200:
        var json = JSON.new()
        if json.parse(body.get_string_from_utf8()) == OK:
            latest_version = json.data[0].name
            return latest_version
        else:
            print("Version fetch: not a valid json")
    else:
        printerr("Version fetch: request failed")
    return ""

func _on_update_pressed(label: RichTextLabel) -> void:
    if not DirAccess.dir_exists_absolute("res://mods"):
        DirAccess.make_dir_absolute("res://mods")
    label.text = "Downloading..."
    menu_http.download_file = "res://mods/com-multiplayer.zip"
    menu_http.request("https://github.com/BdEgh/nophenia-mp/releases/download/%s/com-multiplayer.zip" % latest_version, ["User-Agent: Godot"])
    var result = await menu_http.request_completed
    var code = result[1]
    if result[0] == OK and code == 200:
        label.text = "Updated. Restarting..."
        await get_tree().create_timer(1.5).timeout
        OS.set_restart_on_exit(true, [])
        get_tree().quit()
    else:
        label.text = "Update failed. Code: %d" % code
#endregion

#region RemoteStages
var remote_stages_list: Array[String]
func update_remote_stage_usage():
    if mp_cfg.remote_stage_usage == 0:
        return
    
    webserver_http.cancel_request()
    #print("ADDR:", remote_loader.addr)
    webserver_http.request(remote_loader.addr.path_join("get_stages"))
    var result = await webserver_http.request_completed
    var res: int = result[0]
    var code: int = result[1]
    var body: PackedByteArray = result[3]
    var data
    if res == OK and code == 200:
        var json = JSON.new()
        json.parse(body.get_string_from_ascii())
        data = json.get_data()
        var valid = true
        if data is Array:
            for i in data:
                if not (i is String):
                    valid = false
        else:
            valid = false
        if not valid:
            return
    else:
        return
    remote_stages_list.assign(data)
    #print("fetched remote stages: ", str(remote_stages_list))
#endregion

#region ProjectPatcher
var default_overrides = {
    ["display", "window/subwindows/embed_subwindows"]: true,
    ["xr", "openxr/enabled"]: true,
    ["xr", "shaders/enabled"]: true,
    ["rendering", "renderer/rendering_method"]: "gl_compatibility"
}

func d_to_a(d: Dictionary) -> Array:
    var a: Array
    for k: Array in d:
        a.append([k[0], k[1], d[k]])
    return a

func fetch_all_properties() -> ConfigFile:
    var cfg := ConfigFile.new()
    if game.is_debug:
        if cfg.load("res://project.godot") != OK:
            return null
    else:
        if cfg.load(ProjectSettings.globalize_path("res://override.cfg")) != OK:
            return null
    return cfg
    #cfg.set_value("display", "window/subwindows/embed_subwindows", true)
    #print("Cfgs", cfg.encode_to_text())

func save_all_properties(cfg: ConfigFile) -> void:
    if game.is_debug:
        cfg.save("res://project.godot")
    else:
        cfg.save(ProjectSettings.globalize_path("res://override.cfg"))

func patch_properties(new_props: Array) -> void:
    var cfg := fetch_all_properties()
    if not cfg:
        printerr("Failed to load project properties", self.name)
        return
    var need_restart := false
    for p in new_props:
        var s = p[0]
        var k = p[1]
        var v = p[2]
        var cur_v = cfg.get_value(s, k, default_overrides.get([s, k]))
        if cur_v != v:
            print("Project property changed: %s %s from %s to %s", [s, k, cur_v, v])
            cfg.set_value(s, k, v)
            need_restart = true
    if need_restart:
        var scene = get_tree().current_scene
        if not scene:
            print("bad")
            return
        var _stage = scene.scene_file_path.get_file().get_basename()
        mp_cfg.init_stage = _stage
        save_all_properties(cfg)
        save_config()
        OS.set_restart_on_exit(true, [])
        get_tree().quit()
#endregion
